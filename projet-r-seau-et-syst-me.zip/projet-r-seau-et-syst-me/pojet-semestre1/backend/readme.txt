Résumé des taches faites par tout le monde jusqu'au 26/12 :

Khoa :
Travail fait :
	-Classe food fonction eaten.
	-Classe Bob : Velocity --> fonctionne pas / vision --> ne fonctionne pas. / parthéogènese : code obsolète.

Améliorations possible :
	Dans la classe Bob :
		-Lorsqu'on instancie un bob, ce n'est pas la peine de faire + self.velocityBuffer 
		 dans realVelocity puisque on a rien dans le buffer non ?
		-Ajouter la condition du donut pour le move Left/right/up/down
		-Decouper la fonction move en sous fonctions pour chaque concept de mouvement traité dans le sujet si possible.
	-Commenter les fonctions.

Travail en cours:
	-Adaptation du code à la dernière version du dictio.


Simon : En attente du push
Travail fait:
	-Version de la grille avec un dictio {(x,y):cell}
	-Interface graphique du jeu avec vue isométrique. 
	-Zoom

Amélliorations possible : 
	-Zoom 
	-Séparation rendering des images et des bobs
Travail en cours : 
	-Séparation rendering des images et des bobs
	-Zoom

Paul :
	-En attente du push


Youri :	
Travail fait :
	-Version de la grille avec un dictio {Cell:set()} ??/??
	-Fusion des deux versions et rendu d'une version fonctionnelle. ??/??
	-Test des fonctions dans grille et correction des beugs. -> 26/12
	

Améliorations possible : 
	-Possibiliter d'utiliser un defaultDict au lieu d'un dict.

Travail en cours :
	- Test des fonctions de tout le monde.
	- Affichage du jeu sur terminale avec couleurs. 
	-Suivi du travail commun + correction des bugs + organisation (c'est chiant mais il le faut).



Mokrani :	En attente de push
Travail fait :

Améliorations possible : 
	-

Travail en cours :
	- Menu 
	

----------------------------------- Travail à faire ---------------------------
Cette liste n'est pas encore à jour car en attente de ce qu'a fait tout le monde + ce qui 
fonctionnelle
- Faire tourner le rendu du terminale sur deux threads différents. (+)
- Sprite des bobs. (inclure la modification de la taille + couleur) selon les caractéristiques. (*)
- Reste du poly.

